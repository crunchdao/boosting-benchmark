PMML Generator 
==============

The old Python convert script is removed due to it cannot support the new format of categorical features.

Please refer to https://github.com/jpmml/jpmml-lightgbm.
